package edu.kh.member.controller;

public class LogoutController {

}
